create view T11_FACS as
SELECT F.NAME, count(F.NAME)"Number of factories" FROM F GROUP BY F.NAME HAVING count(F.NAME) > 1
/

