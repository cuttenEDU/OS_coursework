create view T3_FACS as
SELECT "ID","NAME","ADDRESS","DIRECTOR_NAME","DIRECTOR_PHONE" FROM F WHERE F.NAME = 'Швейная фабрика' or F.NAME = 'Алюминиевый завод'
/

