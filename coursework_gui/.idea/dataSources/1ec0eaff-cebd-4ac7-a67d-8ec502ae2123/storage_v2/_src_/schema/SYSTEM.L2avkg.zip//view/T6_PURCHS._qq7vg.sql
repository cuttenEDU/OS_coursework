create view T6_PURCHS as
SELECT P.PART_ID, count(P.AMNT)"Number of purchases" FROM P GROUP BY P.PART_ID
/

