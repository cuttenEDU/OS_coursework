create view T9_PURCHS as
SELECT SUM(P.TOTAL)"Sum of money from part 35" FROM P WHERE P.PART_ID = '35'
/

