create view T9_FACS as
SELECT COUNT(F.NAME)"Amount of factories" FROM F
/

