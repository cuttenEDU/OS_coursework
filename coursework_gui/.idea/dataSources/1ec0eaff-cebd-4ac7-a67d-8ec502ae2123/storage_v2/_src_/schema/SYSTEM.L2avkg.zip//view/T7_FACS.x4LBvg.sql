create view T7_FACS as
SELECT 'В базе '||COUNT(F.NAME)||' заводов типа "'||F.NAME||'"'"Number of factories" FROM F GROUP BY F.NAME
/

