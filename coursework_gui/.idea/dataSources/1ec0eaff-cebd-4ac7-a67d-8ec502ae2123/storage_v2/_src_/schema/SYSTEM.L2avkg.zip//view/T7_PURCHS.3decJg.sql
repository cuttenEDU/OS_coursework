create view T7_PURCHS as
SELECT 'Деталь '||P.PART_ID||' покупалась '||count(AMNT)||' раз(а)'"Number of purchases" FROM P GROUP BY PART_ID
/

