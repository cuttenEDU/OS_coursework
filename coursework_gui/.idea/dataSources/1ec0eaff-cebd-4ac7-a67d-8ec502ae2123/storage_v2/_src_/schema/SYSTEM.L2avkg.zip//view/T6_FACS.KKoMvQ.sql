create view T6_FACS as
SELECT F.NAME, count(F.NAME)"Number of factories" FROM F GROUP BY F.NAME
/

